from .base_llm import BaseLLM


class CoTModel(BaseLLM):
    def format_prompt(self, question: str) -> str:
        """
        Take a question and convert it into a chat template. The LLM will likely answer much
        better if you provide a chat template. self.tokenizer.apply_chat_template can help here
        """

        #raise NotImplementedError()
        messages = [
            {"role": "system", "content": "You are a helpful assistant. Be concise. Always reason step-by-step and provide the final answer inside <answer></answer> tags."},
            {"role": "user", "content": "How many feet are in 2 yards?"},
            {"role": "assistant", "content": "1 yard is 3 feet. So, 2 yards * 3 = 6 feet. <answer>6</answer>"},
            {"role": "user", "content": question}
        ]
        return self.tokenizer.apply_chat_template(messages, add_generation_prompt=True, tokenize=False)


def load() -> CoTModel:
    return CoTModel()


def test_model():
    from .data import Dataset, benchmark

    testset = Dataset("valid")
    model = CoTModel()
    benchmark_result = benchmark(model, testset, 100)
    print(f"{benchmark_result.accuracy=}  {benchmark_result.answer_rate=}")


if __name__ == "__main__":
    from fire import Fire

    Fire({"test": test_model, "load": load})
